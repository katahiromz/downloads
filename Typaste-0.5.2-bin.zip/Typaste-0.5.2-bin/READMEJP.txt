﻿(UTF-8, Japanese)

# Typaste by 片山博文MZ

## これは何？

Typing + Paste == Typaste.

Typaste (タイペースト) は、Ctrl+V による貼り付け処理を割り込み、
まるで打ち込むようにテキスト入力をエミュレートするプログラムです。
これにより、貼り付け禁止を突破できます。

ライセンス: MIT (フリーソフト)

## 対応環境

Windows XP/Vista/7/10で動作します。

## 警告

このソフトを不正な目的で使用しないで下さい。悪用は違法です。

## 更新履歴

- 2019.08.07 ver.0.5.1
    - 初公開。
- 2019.08.14 ver.0.5.2
    - 「ReadMe を開く」を追加。

## 連絡先

片山博文MZ (katahiromz)
katayama.hirofumi.mz@gmail.com
