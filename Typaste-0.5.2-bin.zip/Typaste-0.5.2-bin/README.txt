# Typaste by katahiromz

## What's this?

Typing + Paste == Typaste.

Typaste is a program that intercepts the pasting process by Ctrl+V 
while this window is displayed and emulates text input like typing. 
This allows you to break through the paste prohibition.

License: MIT

## Supported Platforms

It works on Windows XP/Vista/7/10.

## Warning

Please do not use this software for illegal purposes.

## History

- 2019.08.07 ver.0.5.1
    - First release.
- 2019.08.14 ver.0.5.2
    - Add "Open ReadMe".

## Contact Us

Katayama Hirofumi MZ (katahiromz)
katayama.hirofumi.mz@gmail.com
