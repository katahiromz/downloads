This is YappyCam plugins.
Copy the files into the folder of YappyCam.exe.

YappyCam source:
https://github.com/katahiromz/YappyCam

YappyCam binary:
https://katahiromz.web.fc2.com/yappycam/en

YappyCam plugins:
https://github.com/katahiromz/YappyCamPlugins

---
Katayama Hirofumi MZ
katayama.hirofumi.mz@gmail.com
