# Typaste

Typing + Paste == Typaste.

Typaste is a program that intercepts the pasting process by Ctrl+V 
while this window is displayed and emulates text input like typing. 
This allows you to break through the paste prohibition.

It works Windows XP/Vista/7/10.
