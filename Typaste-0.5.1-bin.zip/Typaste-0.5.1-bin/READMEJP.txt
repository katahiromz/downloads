﻿(UTF-8, Japanese)

# Typaste

Typing + Paste == Typaste.

Typaste (タイペースト) は、Ctrl+V による貼り付け処理を割り込み、
まるで打ち込むようにテキスト入力をエミュレートするプログラムです。
これにより、貼り付け禁止を突破できます。

Windows XP/Vista/7/10で動作します。
