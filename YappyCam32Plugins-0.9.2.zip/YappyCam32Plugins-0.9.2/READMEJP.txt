﻿(UTF-8, Japanese)

これは YappyCam プラグイン群です。
ここにあるファイルを YappyCam.exe のフォルダにコピーしてお使い下さい。

YappyCam ソース:
https://github.com/katahiromz/YappyCam

YappyCam バイナリー:
https://katahiromz.web.fc2.com/yappycam/en

YappyCam プラグイン群:
https://github.com/katahiromz/YappyCamPlugins

---
片山博文MZ (かたやまひろふみエムゼッド)
katayama.hirofumi.mz@gmail.com
