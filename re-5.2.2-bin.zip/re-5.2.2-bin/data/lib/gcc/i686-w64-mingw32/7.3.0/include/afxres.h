#ifndef _AFXRES_H
#define _AFXRES_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _INC_WINDOWS
    #include <windows.h>
#endif

#ifndef IDC_STATIC
    #define IDC_STATIC (-1)
#endif

#ifdef __cplusplus
} /* exterm "C" */
#endif

#endif  /* ndef _AFXRES_H */
