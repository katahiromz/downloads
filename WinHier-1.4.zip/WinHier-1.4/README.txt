# WinHier by katahiromz

WinHier is a useful utility to investigate window hierarchy and properties.

Platforms: Windows XP/Vista/7/10
