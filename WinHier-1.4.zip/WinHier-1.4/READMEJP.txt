﻿# WinHier by 片山博文MZ

WinHier はウィンドウの階層構造やプロパティを調べるのに便利なツールです。

対応環境: Windows XP/Vista/7/10
