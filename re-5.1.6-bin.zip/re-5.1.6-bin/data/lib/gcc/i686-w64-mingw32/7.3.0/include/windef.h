#ifndef _WINDEF_
#define _WINDEF_

#include "winnt.h"

#endif  /* ndef _WINDEF_ */
